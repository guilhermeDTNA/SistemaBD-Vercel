SET GLOBAL log_bin_trust_function_creators = 1;

DROP FUNCTION IF EXISTS f_calculaFinancas;
CREATE FUNCTION f_calculaFinancas () 
RETURNS FLOAT DETERMINISTIC
BEGIN
  DECLARE receita FLOAT;
  DECLARE despesas FLOAT;
  DECLARE result FLOAT;
  SELECT SUM(c.mensalidade) INTO receita FROM curso c JOIN matricula m ON m.id_curso=c.id_curso;SELECT SUM(valor_despesa) INTO despesas FROM despesa;
  SELECT receita-despesas INTO result;
  RETURN result;
END


DROP PROCEDURE IF EXISTS sp_calculaFinancas;
CREATE PROCEDURE sp_calculaFinancas()
BEGIN
	DECLARE receita FLOAT;
	DECLARE despesas FLOAT;
	SELECT SUM(c.mensalidade) INTO receita FROM curso c JOIN matricula m ON m.id_curso=c.id_curso;
	SELECT SUM(valor_despesa) INTO despesas FROM despesa;
	SELECT receita-despesas;
END 


CREATE PROCEDURE sp_curso_aluno (id_curso INT)
BEGIN
	SELECT c.nome_curso AS 'Curso', CONCAT(a.nome_aluno, ' ', a.sobrenome_aluno) AS 'Aluno'
	 FROM aluno a JOIN curso c JOIN matricula m ON a.id_aluno=m.id_aluno AND
	 c.id_curso=m.id_curso AND m.id_curso = id_curso ORDER BY c.nome_curso;
END


CREATE PROCEDURE sp_dadosAluno(id INT)
BEGIN
	SELECT nome_aluno, sobrenome_aluno, email_aluno, data_nasc, rua_aluno, numero, cidade_aluno, estado_aluno FROM aluno WHERE id_aluno = id;
END


CREATE PROCEDURE sp_dadosCurso (id INT)
BEGIN
	SELECT id_professor, nome_curso, qtd_alunos, mensalidade FROM curso WHERE id_curso = id;
END


CREATE PROCEDURE sp_dadosDespesa(id INT)
BEGIN
	SELECT id_diretor, nome_despesa, valor_despesa FROM despesa WHERE id_despesa = id;
END



CREATE PROCEDURE sp_dadosDiretor (id INT)
BEGIN
	SELECT nome_diretor, sobrenome_diretor, email_diretor, data_nasc, rua_diretor, numero, cidade_diretor, estado_diretor, senha, usuario FROM diretor WHERE id_diretor = id;
END


CREATE PROCEDURE sp_dadosMatricula (id INT)
BEGIN
	SELECT id_aluno, id_curso FROM matricula WHERE id_matricula = id;
END


CREATE PROCEDURE sp_dadosProfessor (id INT)
BEGIN
	SELECT nome_professor, sobrenome_professor, email_professor, data_nasc, rua_professor, numero, cidade_professor, estado_professor, salario FROM professor WHERE id_professor = id;
END
