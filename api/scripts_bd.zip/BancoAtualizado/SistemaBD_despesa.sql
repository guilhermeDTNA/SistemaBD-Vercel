CREATE TABLE `despesa` (
  `id_despesa` int(11) NOT NULL AUTO_INCREMENT,
  `id_diretor` int(11) NOT NULL,
  `nome_despesa` varchar(20) NOT NULL,
  `valor_despesa` float NOT NULL,
  PRIMARY KEY (`id_despesa`),
  KEY `id_diretor` (`id_diretor`),
  CONSTRAINT `despesa_ibfk_1` FOREIGN KEY (`id_diretor`) REFERENCES `diretor` (`id_diretor`)
);

INSERT INTO `despesa` VALUES (7,3,'Conta de Água',300),(8,4,'Conta de NBet',350);
