CREATE TABLE `aluno` (
  `id_aluno` int(11) NOT NULL AUTO_INCREMENT,
  `nome_aluno` varchar(20) NOT NULL,
  `sobrenome_aluno` varchar(20) NOT NULL,
  `email_aluno` varchar(30) NOT NULL,
  `data_nasc` date NOT NULL,
  `rua_aluno` varchar(30) NOT NULL,
  `numero` int(11) NOT NULL,
  `cidade_aluno` varchar(30) NOT NULL,
  `estado_aluno` varchar(30) NOT NULL,
  PRIMARY KEY (`id_aluno`)
);

INSERT INTO `aluno` VALUES (11,'JoÃ£o','Santos','joao@hotmail.com','1992-06-20','Avenida Bias Fortes',100,'Curvelo','MG'),(12,'Maria','Celeste','maria@gmail.com','1994-05-01','Avenida Ayrton Senna',136,'SÃ£o Paulo','SP'),(13,'Fabiano','Soares','fabiano@yahoo.com','1995-12-31','Avenida Mal. EsperidiÃ£o Rosa',400,'Belo Horizonte','MG'),(14,'Teste1','aaa','teste@teste.com','2020-10-01','Teste ruaaaa',122,'Diamantina ','AC'),(17,'JoÃ£o','Santos','joao@ufvjm.edu.br','2020-10-01','Amargura',2,'Tombos','AL');
