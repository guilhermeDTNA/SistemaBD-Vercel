CREATE TABLE `professor` (
  `id_professor` int(11) NOT NULL AUTO_INCREMENT,
  `nome_professor` varchar(20) NOT NULL,
  `sobrenome_professor` varchar(20) NOT NULL,
  `email_professor` varchar(30) NOT NULL,
  `data_nasc` date NOT NULL,
  `rua_professor` varchar(60) NOT NULL,
  `numero` int(11) NOT NULL,
  `cidade_professor` varchar(30) NOT NULL,
  `estado_professor` varchar(30) NOT NULL,
  `salario` double NOT NULL,
  PRIMARY KEY (`id_professor`)
);

INSERT INTO `professor` VALUES (5,'Eduardo','Villas Boas','eduardo@bol.com','1952-01-20','da Caridade',136,'Diamantina','MG',5000),(6,'Henrique','Nolasco','henrique@hotmail.com','1952-06-02','Professor Eurico Rabelo',520,'Rio de Janeiro','RJ',5000),(7,'JosÃ©','aaaaa','jose@uol.com','1960-03-21','Avenida SÃ­lvio FelÃ­cio dos Santos',21,'Diamantina','AL',5000);
