CREATE TABLE `curso` (
  `id_curso` int(11) NOT NULL AUTO_INCREMENT,
  `id_professor` int(11) NOT NULL,
  `nome_curso` varchar(50) NOT NULL,
  `qtd_alunos` int(11) NOT NULL,
  `mensalidade` float NOT NULL,
  PRIMARY KEY (`id_curso`),
  KEY `id_professor` (`id_professor`),
  CONSTRAINT `curso_ibfk_1` FOREIGN KEY (`id_professor`) REFERENCES `professor` (`id_professor`)
)
