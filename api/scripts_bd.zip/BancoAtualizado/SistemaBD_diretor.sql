CREATE TABLE `diretor` (
  `id_diretor` int(11) NOT NULL AUTO_INCREMENT,
  `nome_diretor` varchar(20) NOT NULL,
  `sobrenome_diretor` varchar(20) NOT NULL,
  `email_diretor` varchar(30) NOT NULL,
  `data_nasc` date NOT NULL,
  `rua_diretor` varchar(30) NOT NULL,
  `numero` int(11) NOT NULL,
  `cidade_diretor` varchar(30) NOT NULL,
  `estado_diretor` varchar(30) NOT NULL,
  `senha` varchar(64) NOT NULL,
  `usuario` varchar(40) NOT NULL,
  PRIMARY KEY (`id_diretor`)
)

INSERT INTO `diretor` VALUES (1,'Rita','Gaiola','rita@gmail.com','1955-04-12','Rua da Liberdade',120,'Belo Horizonte','MG','5f9197579d4f131520b4d8218ff66709','admin');
